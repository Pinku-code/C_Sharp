using System;

class program
{
    static void Main()
    {
        Console.WriteLine("Hello");
        Console.WriteLine("YourName");
        Console.ReadKey();
    }
}
