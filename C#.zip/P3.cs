using System;

class Program
{
    static void Main()
    {
        Console.WriteLine("Max value of int: " + int.MaxValue);
        Console.WriteLine("Min value of int: " + int.MinValue);

        // Repeat for other data types as needed
    }
}
